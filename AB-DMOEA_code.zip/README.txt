Welcome to access my github homepage, my papers and codes are avaliable on the website. 

If you find this code useful in your work, please cite the 
following paper "Hu Peng, Jianpeng Xiong, Chen Pi, Xinyu Zhou, Zhijian Wu. A dynamic multi-objective optimization evolutionary algorithm with adaptive boosting. Swarm and Evolutionary Computation, 2024, 101621."






